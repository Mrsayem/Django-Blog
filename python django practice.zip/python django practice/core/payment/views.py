from django.shortcuts import render
from django.http import HttpResponse
from datetime import datetime
from payment.models import pay_method

# Create your views here.
def paymentHome(request):
    
    return render(request,'index.html')
def payAbout(request):
    return render(request,'content/base.html')
def about(request):
    return render(request, 'payment/payment.html')
def payment_method(request):
    pay_m=pay_method.objects.all()
    return render(request,'payment/pay.html',{'pay':pay_m})