from django.urls import path
from . import views
urlpatterns = [
    path('',views.paymentHome),
    path('pay/',views.payAbout),
    path('about/',views.about,name="paymentpage"),
    path('paymethod/',views.payment_method)
]
