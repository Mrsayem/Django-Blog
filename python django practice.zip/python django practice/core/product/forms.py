from django import forms

class RecentProducts(forms.Form):
    mobile = forms.CharField()
    laptop=forms.CharField(label="enter your laptop name ")
    email=forms.EmailField(label_suffix=' = ')
    about=forms.CharField(help_text="describe your laptop")
    textarea=forms.CharField(widget=forms.Textarea)
    checkbox=forms.CharField(widget=forms.CheckboxInput)
    files=forms.CharField(widget=forms.FileInput)