from django.shortcuts import render
from product.forms import RecentProducts
# Create your views here.
def details(request):
    if request.method == 'POST':
        frm=RecentProducts(request.post)
        print(frm)
    
    return render(request,'product/recent.html',{'form':frm})